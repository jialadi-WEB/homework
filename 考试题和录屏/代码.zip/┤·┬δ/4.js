// 补全函数完成功能，传入数组中找到任意3个数字(数字不能重复使用)的和是10的倍数，将所有组合打印下来 
// var arr =[10,2,8,4,6];
//  function printSumIs10MoM( arr){
//      for(var i =0;i<arr.length ;i++){
//          for(var j =i+1;j<arr.length; j++){
//              for(var k =j+1;k<arr.length;k++){
//                  if((arr[i]+arr[k]+arr[j])%10==0){
//                      console.log(arr[i],arr[k],arr[j]+"三个数的和是十的倍数")
//                  }
//              }
//          }
//      }
//  } 
//  printSumIs10MoM(arr)
